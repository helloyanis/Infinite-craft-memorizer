# Infinite-craft-toolkit
A utility to remember how to get specific items in [infinite craft](https://neal.fun/infinite-craft/)!
Also allows you to create your own items.

# Download for [Firefox](https://addons.mozilla.org/addon/infinite-craft-memorizer/)!

Once you got it, you can get some pre-built data on [this GitHub Gist](https://gist.github.com/helloyanis/8b56a698dbbe37de8b8314961697fafc)!
