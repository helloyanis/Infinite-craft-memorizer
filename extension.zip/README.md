# Infinite-craft-memorizer
A utility to remember how to get specific items in [infinite craft](https://neal.fun/infinite-craft/)
Currently under review by the Mozilla team! Avilable soon on the Firefox Add-ons store!